Project Overview – describe goals and technologies.

Directory Structure – outline each folder’s purpose.

Setup Instructions – how to open/edit files.

Backup Guide – how to run scripts/backup.sh.

Testing – steps to verify HTML renders, backups succeed.
